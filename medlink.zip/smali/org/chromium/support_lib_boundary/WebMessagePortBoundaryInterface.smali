###### Class org.chromium.support_lib_boundary.WebMessagePortBoundaryInterface (org.chromium.support_lib_boundary.WebMessagePortBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/WebMessagePortBoundaryInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract close()V
.end method

.method public abstract postMessage(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract setWebMessageCallback(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract setWebMessageCallback(Ljava/lang/reflect/InvocationHandler;Landroid/os/Handler;)V
.end method
