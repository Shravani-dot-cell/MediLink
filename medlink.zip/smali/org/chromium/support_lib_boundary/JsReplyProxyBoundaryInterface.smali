###### Class org.chromium.support_lib_boundary.JsReplyProxyBoundaryInterface (org.chromium.support_lib_boundary.JsReplyProxyBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/JsReplyProxyBoundaryInterface;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lorg/chromium/support_lib_boundary/IsomorphicObjectBoundaryInterface;


# virtual methods
.method public abstract postMessage(Ljava/lang/String;)V
.end method

.method public abstract postMessageWithPayload(Ljava/lang/reflect/InvocationHandler;)V
.end method
