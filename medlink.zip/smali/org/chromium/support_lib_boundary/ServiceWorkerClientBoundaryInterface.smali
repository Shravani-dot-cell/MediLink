###### Class org.chromium.support_lib_boundary.ServiceWorkerClientBoundaryInterface (org.chromium.support_lib_boundary.ServiceWorkerClientBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/ServiceWorkerClientBoundaryInterface;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lorg/chromium/support_lib_boundary/FeatureFlagHolderBoundaryInterface;


# virtual methods
.method public abstract shouldInterceptRequest(Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;
.end method
