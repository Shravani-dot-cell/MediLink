###### Class org.chromium.support_lib_boundary.WebViewRendererBoundaryInterface (org.chromium.support_lib_boundary.WebViewRendererBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/WebViewRendererBoundaryInterface;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lorg/chromium/support_lib_boundary/IsomorphicObjectBoundaryInterface;


# virtual methods
.method public abstract terminate()Z
.end method
