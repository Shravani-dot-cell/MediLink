###### Class org.chromium.support_lib_boundary.ServiceWorkerControllerBoundaryInterface (org.chromium.support_lib_boundary.ServiceWorkerControllerBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/ServiceWorkerControllerBoundaryInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getServiceWorkerWebSettings()Ljava/lang/reflect/InvocationHandler;
.end method

.method public abstract setServiceWorkerClient(Ljava/lang/reflect/InvocationHandler;)V
.end method
