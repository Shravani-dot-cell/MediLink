###### Class org.chromium.support_lib_boundary.WebMessageCallbackBoundaryInterface (org.chromium.support_lib_boundary.WebMessageCallbackBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/WebMessageCallbackBoundaryInterface;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lorg/chromium/support_lib_boundary/FeatureFlagHolderBoundaryInterface;


# virtual methods
.method public abstract onMessage(Ljava/lang/reflect/InvocationHandler;Ljava/lang/reflect/InvocationHandler;)V
.end method
