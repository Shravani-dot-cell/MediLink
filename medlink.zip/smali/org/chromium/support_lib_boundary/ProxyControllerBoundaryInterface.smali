###### Class org.chromium.support_lib_boundary.ProxyControllerBoundaryInterface (org.chromium.support_lib_boundary.ProxyControllerBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/ProxyControllerBoundaryInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract clearProxyOverride(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
.end method

.method public abstract setProxyOverride([[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
.end method

.method public abstract setProxyOverride([[Ljava/lang/String;[Ljava/lang/String;Ljava/lang/Runnable;Ljava/util/concurrent/Executor;Z)V
.end method
