###### Class org.chromium.support_lib_boundary.WebResourceErrorBoundaryInterface (org.chromium.support_lib_boundary.WebResourceErrorBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/WebResourceErrorBoundaryInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getDescription()Ljava/lang/CharSequence;
.end method

.method public abstract getErrorCode()I
.end method
