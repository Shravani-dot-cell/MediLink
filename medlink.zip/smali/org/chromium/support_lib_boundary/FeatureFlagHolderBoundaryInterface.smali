###### Class org.chromium.support_lib_boundary.FeatureFlagHolderBoundaryInterface (org.chromium.support_lib_boundary.FeatureFlagHolderBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/FeatureFlagHolderBoundaryInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract getSupportedFeatures()[Ljava/lang/String;
.end method
