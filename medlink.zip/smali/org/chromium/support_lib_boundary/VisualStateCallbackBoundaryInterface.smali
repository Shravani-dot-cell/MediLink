###### Class org.chromium.support_lib_boundary.VisualStateCallbackBoundaryInterface (org.chromium.support_lib_boundary.VisualStateCallbackBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/VisualStateCallbackBoundaryInterface;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract onComplete(J)V
.end method
