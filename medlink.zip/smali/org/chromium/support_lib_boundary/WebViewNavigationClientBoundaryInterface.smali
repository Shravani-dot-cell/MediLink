###### Class org.chromium.support_lib_boundary.WebViewNavigationClientBoundaryInterface (org.chromium.support_lib_boundary.WebViewNavigationClientBoundaryInterface)
.class public interface abstract Lorg/chromium/support_lib_boundary/WebViewNavigationClientBoundaryInterface;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Lorg/chromium/support_lib_boundary/FeatureFlagHolderBoundaryInterface;


# virtual methods
.method public abstract onFirstContentfulPaint(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract onNavigationCompleted(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract onNavigationRedirected(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract onNavigationStarted(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract onPageDOMContentLoadedEventFired(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract onPageDeleted(Ljava/lang/reflect/InvocationHandler;)V
.end method

.method public abstract onPageLoadEventFired(Ljava/lang/reflect/InvocationHandler;)V
.end method
