###### Class x.uy4 (x.uy4)
.class public final Lx/uy4;
.super Lx/xg4;
.source ""

# interfaces
.implements Lx/wy4;


# virtual methods
.method public final zzb(Ljava/util/List;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lx/xg4;->zza()Landroid/os/Parcel;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    .line 6
    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    invoke-virtual {p0, p1, v0}, Lx/xg4;->zzda(ILandroid/os/Parcel;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
