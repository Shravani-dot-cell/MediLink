###### Class x.mx6 (x.mx6)
.class public final Lx/mx6;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I


# direct methods
.method public constructor <init>(IIII)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lx/mx6;->a:I

    .line 5
    .line 6
    iput p2, p0, Lx/mx6;->b:I

    .line 7
    .line 8
    iput p3, p0, Lx/mx6;->c:I

    .line 9
    .line 10
    iput p4, p0, Lx/mx6;->d:I

    .line 11
    .line 12
    return-void
.end method
