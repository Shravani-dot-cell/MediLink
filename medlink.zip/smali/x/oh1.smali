###### Class x.oh1 (x.oh1)
.class public abstract Lx/oh1;
.super Ljava/lang/Object;
.source ""


# instance fields
.field public final a:I

.field public final b:I


# direct methods
.method public constructor <init>(II)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lx/oh1;->a:I

    .line 5
    .line 6
    iput p2, p0, Lx/oh1;->b:I

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public abstract a(Lx/ml0;)V
.end method
