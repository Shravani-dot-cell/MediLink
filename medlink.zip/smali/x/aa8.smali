###### Class x.aa8 (x.aa8)
.class public final Lx/aa8;
.super Lx/dza;
.source ""

# interfaces
.implements Lx/m4b;


# static fields
.field private static final zzb:Lx/aa8;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Ljava/lang/String;

.field private zzg:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lx/aa8;

    .line 2
    .line 3
    invoke-direct {v0}, Lx/aa8;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lx/aa8;->zzb:Lx/aa8;

    .line 7
    .line 8
    const-class v1, Lx/aa8;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lx/dza;->l(Ljava/lang/Class;Lx/dza;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lx/dza;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, ""

    .line 5
    .line 6
    iput-object v0, p0, Lx/aa8;->zzf:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method

.method public static m()Lx/a98;
    .registers 1

    .line 1
    sget-object v0, Lx/aa8;->zzb:Lx/aa8;

    .line 2
    .line 3
    invoke-virtual {v0}, Lx/dza;->g()Lx/iya;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lx/a98;

    .line 8
    .line 9
    return-object v0
.end method

.method public static synthetic n(Lx/aa8;Ljava/lang/String;)V
    .registers 3

    .line 1
    iget v0, p0, Lx/aa8;->zzd:I

    .line 2
    .line 3
    or-int/lit8 v0, v0, 0x2

    .line 4
    .line 5
    iput v0, p0, Lx/aa8;->zzd:I

    .line 6
    .line 7
    iput-object p1, p0, Lx/aa8;->zzf:Ljava/lang/String;

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic o(Lx/aa8;J)V
    .registers 4

    .line 1
    iget v0, p0, Lx/aa8;->zzd:I

    .line 2
    .line 3
    or-int/lit8 v0, v0, 0x4

    .line 4
    .line 5
    iput v0, p0, Lx/aa8;->zzd:I

    .line 6
    .line 7
    iput-wide p1, p0, Lx/aa8;->zzg:J

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic p(Lx/aa8;I)V
    .registers 2

    .line 1
    add-int/lit8 p1, p1, -0x2

    .line 2
    .line 3
    iput p1, p0, Lx/aa8;->zze:I

    .line 4
    .line 5
    iget p1, p0, Lx/aa8;->zzd:I

    .line 6
    .line 7
    or-int/lit8 p1, p1, 0x1

    .line 8
    .line 9
    iput p1, p0, Lx/aa8;->zzd:I

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final f(I)Ljava/lang/Object;
    .registers 5

    .line 1
    add-int/lit8 p1, p1, -0x1

    .line 2
    .line 3
    if-eqz p1, :cond_39

    .line 4
    .line 5
    const/4 v0, 0x2

    .line 6
    if-eq p1, v0, :cond_23

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    if-eq p1, v0, :cond_1d

    .line 10
    .line 11
    const/4 v0, 0x4

    .line 12
    if-eq p1, v0, :cond_15

    .line 13
    .line 14
    const/4 v0, 0x5

    .line 15
    if-ne p1, v0, :cond_13

    .line 16
    .line 17
    sget-object p1, Lx/aa8;->zzb:Lx/aa8;

    .line 18
    .line 19
    return-object p1

    .line 20
    :cond_13
    const/4 p1, 0x0

    .line 21
    throw p1

    .line 22
    :cond_15
    new-instance p1, Lx/a98;

    .line 23
    .line 24
    sget-object v0, Lx/aa8;->zzb:Lx/aa8;

    .line 25
    .line 26
    invoke-direct {p1, v0}, Lx/iya;-><init>(Lx/dza;)V

    .line 27
    .line 28
    .line 29
    return-object p1

    .line 30
    :cond_1d
    new-instance p1, Lx/aa8;

    .line 31
    .line 32
    invoke-direct {p1}, Lx/aa8;-><init>()V

    .line 33
    .line 34
    .line 35
    return-object p1

    .line 36
    :cond_23
    const-string p1, "zzf"

    .line 37
    .line 38
    const-string v0, "zzg"

    .line 39
    .line 40
    const-string v1, "zzd"

    .line 41
    .line 42
    const-string v2, "zze"

    .line 43
    .line 44
    filled-new-array {v1, v2, p1, v0}, [Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    sget-object v0, Lx/aa8;->zzb:Lx/aa8;

    .line 49
    .line 50
    new-instance v1, Lx/l5b;

    .line 51
    .line 52
    const-string v2, "\u0004\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u100c\u0000\u0002\u1208\u0001\u0003\u1002\u0002"

    .line 53
    .line 54
    invoke-direct {v1, v0, v2, p1}, Lx/l5b;-><init>(Lx/i4b;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    return-object v1

    .line 58
    :cond_39
    const/4 p1, 0x1

    .line 59
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    return-object p1
.end method
