###### Class x.f24 (x.f24)
.class public final Lx/f24;
.super Lx/o74;
.source ""


# instance fields
.field public final synthetic C:Lx/tc4;


# direct methods
.method public constructor <init>(Lx/tc4;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lx/f24;->C:Lx/tc4;

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lx/o74;-><init>(Lx/tc4;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(I)Ljava/lang/Object;
    .registers 3

    .line 1
    sget-object v0, Lx/tc4;->G:Ljava/lang/Object;

    .line 2
    .line 3
    iget-object v0, p0, Lx/f24;->C:Lx/tc4;

    .line 4
    .line 5
    invoke-virtual {v0}, Lx/tc4;->b()[Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    aget-object p1, v0, p1

    .line 10
    .line 11
    return-object p1
.end method
